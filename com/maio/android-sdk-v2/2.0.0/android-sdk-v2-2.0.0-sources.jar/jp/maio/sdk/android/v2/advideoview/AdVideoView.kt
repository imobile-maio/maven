package jp.maio.sdk.android.v2.advideoview

import jp.maio.sdk.android.v2.ITimerScheduler
import java.net.URL
import java.util.*

internal enum class VideoViewStatus {
    None,
    Loading,
    Loaded,
    Playing,
    Paused,
    Completed,
    FailedToLoad,
    FailedToPlay
}

internal interface IAdVideoView {
    val currentTimeWatcher: ITimerScheduler
    val status: VideoViewStatus
    fun play()
    fun pause()
    fun rewind()
    fun load(url: URL)
    fun watchCurrentTime(intervalTime: Long)
    fun unwatchCurrentTime()
}

internal interface IAdVideoViewCallback {
    fun onError()
    fun onPrepared()
    fun onComplete()
}

internal interface IVideoViewLoadCallback {
    fun loaded()
    fun failed(errorCode: Int)
}

internal interface IVideoViewPlaybackCallback {
    fun playing()
    fun paused()
    fun completed()
    fun changedCurrentTime(currentTime: Long)
    fun failed(errorCode: Int)
}

internal class AdVideoView(
    private var videoViewLoadCallBack: IVideoViewLoadCallback?,
    private var videoViewPlayback: IVideoViewPlaybackCallback?,
    private var videoViewWrapper: IVideoViewWrapper
) :

    IAdVideoView {

    override var status: VideoViewStatus =
        VideoViewStatus.None
        private set

    private val adVideoViewCallback =
        object : IAdVideoViewCallback {
            override fun onError() {
                when (status) {
                    VideoViewStatus.Loading -> {
                        status =
                            VideoViewStatus.FailedToLoad
                        videoViewLoadCallBack?.failed(1)
                    }
                    else -> {
                        if (videoViewWrapper.isPlaying()) videoViewWrapper.stopPlayback()
                        status =
                            VideoViewStatus.FailedToPlay
                        videoViewPlayback?.failed(1)
                    }
                }
            }

            override fun onPrepared() {
                videoViewLoadCallBack?.loaded()
                status =
                    VideoViewStatus.Loaded
            }

            override fun onComplete() {
                status =
                    VideoViewStatus.Completed
                videoViewPlayback?.completed()
            }
        }

    private fun timerTaskBody() {
        if (videoViewWrapper.isPlaying()) {
            val elapsed: Int = videoViewWrapper.currentPosition()
            videoViewPlayback?.changedCurrentTime(elapsed.toLong() / 1000)
        }
    }

    override val currentTimeWatcher: ITimerScheduler =
        CurrentTimeWatcher()

    override fun play() {
        when (status) {
            VideoViewStatus.Loaded, VideoViewStatus.Paused, VideoViewStatus.Completed -> {
                status =
                    VideoViewStatus.Playing
                videoViewWrapper.play()
                videoViewPlayback?.playing()
            }

            else -> {}
        }
    }

    override fun pause() {
        when (status) {
            VideoViewStatus.Playing -> {
                status =
                    VideoViewStatus.Paused
                videoViewWrapper.pause()
                videoViewPlayback?.paused()
            }

            else -> {}
        }
    }

    override fun load(url: URL) {
        status = VideoViewStatus.Loading
        videoViewWrapper.load(url, adVideoViewCallback)
    }

    override fun rewind() {
        videoViewWrapper.seekTo(0)
    }

    override fun watchCurrentTime(intervalTime : Long) {
        var task: TimerTask = object : TimerTask() {
            override fun run() {
                timerTaskBody()
            }
        }
        currentTimeWatcher.start(intervalTime  * 1000, task)
    }

    override fun unwatchCurrentTime() {
        currentTimeWatcher.stop()
    }
}

class CurrentTimeWatcher : ITimerScheduler {
    private var started = false
    private lateinit var timer: Timer

    override fun start(interval: Long, task: TimerTask) {
        if (!started) {
            started = true
            timer = Timer()
            timer.schedule(task, 1, interval)
        }
    }

    override fun stop() {
        if (started) {
            timer.cancel()
            timer.purge()
            started = false
        }
    }
}