package jp.maio.sdk.android.v2.device

import android.os.Build
import java.util.*

internal interface IBuild {
    val deviceBrand: String
    val osVersion: String
    val language: String
    val deviceName: String
}

internal class Build(
    override val deviceBrand: String,
    override val osVersion: String,
    override val language: String,
    override val deviceName: String
) : IBuild {}


internal interface IBuildProvider {
    val build: IBuild
}

internal class BuildProvider : IBuildProvider {
    override var build: IBuild = Build(
        Build.BRAND,
        Build.VERSION.RELEASE,
        Locale.getDefault().language,
        Build.DEVICE
    )
}