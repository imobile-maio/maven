package jp.maio.sdk.android.v2.fullscreenad

import jp.maio.sdk.android.v2.errorcode.ErrorCode
import jp.maio.sdk.android.v2.rewarddata.RewardData

internal interface IFullScreenAdShowCallback {
    fun opened()
    fun closed()
    fun clicked()
    fun rewarded(rewardData: RewardData)
    fun failed(errorCode: ErrorCode)
}