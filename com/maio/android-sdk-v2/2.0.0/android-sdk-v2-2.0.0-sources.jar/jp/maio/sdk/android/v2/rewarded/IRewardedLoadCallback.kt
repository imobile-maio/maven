package jp.maio.sdk.android.v2.rewarded

import jp.maio.sdk.android.v2.errorcode.ErrorCode

interface IRewardedLoadCallback {
    fun loaded(rewarded: Rewarded) {}
    fun failed(rewarded: Rewarded, errorCode: Int) {}
}