package jp.maio.sdk.android.v2.device

import android.content.Context
import android.media.AudioManager
import jp.maio.sdk.android.v2.IContextWrapper
import android.os.Build

internal interface IAudio {
    val value: String
}

internal class Audio(
    override val value: String
) : IAudio {}

internal interface IAudioProvider {
    val audio: Array<IAudio>
}

internal class AudioProvider(contextWrapper: IContextWrapper) : IAudioProvider {

    override lateinit var audio: Array<IAudio>

    init {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            val audioManager =
                contextWrapper.getContext.getSystemService(Context.AUDIO_SERVICE) as AudioManager
            val devices = audioManager.getDevices(AudioManager.GET_DEVICES_OUTPUTS)
            var audioList = ArrayList<IAudio>()

            for (device in devices) {
                var audioListItem = Audio(device.type.toString())
                audioList.add(audioListItem)
            }
            audio = audioList.toTypedArray()
        }
    }
}