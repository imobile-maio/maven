package jp.maio.sdk.android.v2.device

import android.content.Context
import android.net.ConnectivityManager
import android.net.NetworkCapabilities
import jp.maio.sdk.android.v2.IContextWrapper
import android.os.Build

internal interface INetworkConnectionProvider {
    val networkType: NetworkConnectionType
}

internal class NetworkConnectionProvider(contextWrapper: IContextWrapper) : INetworkConnectionProvider {
    override var networkType: NetworkConnectionType = NetworkConnectionType.None

    init {
        val cm =
            contextWrapper.getContext.getSystemService(Context.CONNECTIVITY_SERVICE) as ConnectivityManager
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {

            val n = cm.activeNetwork

            if (n == null) {
                networkType = NetworkConnectionType.None
            } else {
                val nc = cm.getNetworkCapabilities(n)
                networkType = if (nc!!.hasTransport(NetworkCapabilities.TRANSPORT_WIFI)) {
                    NetworkConnectionType.Wifi
                } else if (nc.hasTransport(NetworkCapabilities.TRANSPORT_CELLULAR)) {
                    NetworkConnectionType.Cellular
                } else {
                    NetworkConnectionType.None
                }
            }
        }
    }
}

internal enum class NetworkConnectionType {
    None,
    Wifi,
    Cellular
}