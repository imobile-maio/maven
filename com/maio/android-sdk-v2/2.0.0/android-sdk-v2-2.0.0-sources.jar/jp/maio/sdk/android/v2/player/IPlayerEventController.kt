package jp.maio.sdk.android.v2.player

import jp.maio.sdk.android.v2.fullscreenad.IFullScreenAdLoadCallback
import jp.maio.sdk.android.v2.fullscreenad.IFullScreenAdShowCallback
import jp.maio.sdk.android.v2.request.MaioRequest

internal interface IPlayerEventController {
   fun load(request: MaioRequest, loadCallback: IFullScreenAdLoadCallback) {

    }
    fun show(showCallback: IFullScreenAdShowCallback){

    }
}