package jp.maio.sdk.android.v2.player


import android.content.Context
import android.graphics.drawable.Drawable
import android.util.AttributeSet
import android.view.GestureDetector
import android.view.MotionEvent
import android.widget.ImageButton

internal interface ForceCloseViewCallback {
    fun didReceiveForceClose()
}

internal class ForceCloseView @JvmOverloads constructor(
    context: Context, attrs: AttributeSet? = null, defStyleAttr: Int = 0
) : androidx.appcompat.widget.AppCompatImageButton(context, attrs, defStyleAttr) {

    var callback: ForceCloseViewCallback? = null

    init {
        val gestureDetector = GestureDetector(context, object : GestureDetector.SimpleOnGestureListener() {
            override fun onSingleTapConfirmed(e: MotionEvent): Boolean {
                callback?.didReceiveForceClose()
                return true
            }
        })

        this.setOnTouchListener { _, event ->
            gestureDetector.onTouchEvent(event)
            true
        }

        //val image: Drawable? = context.getDrawable(R.drawable.force_close_button) // Assuming the image is in the drawable folder
        //this.setImageDrawable(image)
    }

    companion object {
        fun create(context: Context): ForceCloseView {
            return ForceCloseView(context)
        }
    }
}