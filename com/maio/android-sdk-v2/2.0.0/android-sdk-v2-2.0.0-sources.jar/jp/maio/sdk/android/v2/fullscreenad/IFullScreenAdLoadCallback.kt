package jp.maio.sdk.android.v2.fullscreenad

import jp.maio.sdk.android.v2.errorcode.ErrorCode

internal interface IFullScreenAdLoadCallback {
    fun loaded()
    fun failed(errorCode: ErrorCode)
}