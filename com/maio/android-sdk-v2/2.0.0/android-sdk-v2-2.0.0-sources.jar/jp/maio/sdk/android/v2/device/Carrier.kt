package jp.maio.sdk.android.v2.device

import android.content.Context
import android.telephony.TelephonyManager
import jp.maio.sdk.android.v2.IContextWrapper

internal interface ICarrierProvider {
    val carrier: Array<ICarrier>
}

internal interface ICarrier {
    val carrierName: String
    val mcc: String
    val mnc: String?
    val isUsing: Boolean
}

internal class Carrier constructor(
    override val carrierName: String,
    override val mcc: String,
    override val mnc: String?,
    override val isUsing: Boolean
) :
    ICarrier {}

internal class CarrierProvider(contextWrapper: IContextWrapper) : ICarrierProvider {
    var carrierName: String = ""
    var mcc: String = ""
    var mnc: String? = ""

    init {
        val manager =
            contextWrapper.getContext.getSystemService(Context.TELEPHONY_SERVICE) as TelephonyManager
        carrierName = manager.networkOperatorName
        val plmn = manager.networkOperator
        if (!plmn.equals("")) {
            mcc = plmn.substring(0, 3)
            mnc = plmn.substring(3, plmn.length)
        }
    }

    override var carrier: Array<ICarrier> = arrayOf(Carrier(carrierName, mcc, mnc, true))
}