package jp.maio.sdk.android.v2;

import java.util.*

internal interface ITimerScheduler {
    fun start(interval: Long, task: TimerTask)
    fun stop()
}