package jp.maio.sdk.android.v2.player

import android.content.Context
import android.graphics.Bitmap
import android.graphics.Color
import android.net.Uri
import android.os.Build
import android.util.Log
import android.webkit.ConsoleMessage
import android.webkit.ValueCallback
import android.webkit.WebChromeClient
import android.webkit.WebResourceRequest
import android.webkit.WebView
import android.webkit.WebViewClient
import androidx.annotation.RequiresApi
import org.json.JSONObject
import java.io.BufferedInputStream
import java.io.File
import java.io.FileOutputStream
import java.io.InputStream
import java.net.URL
import java.util.zip.ZipEntry
import java.util.zip.ZipInputStream


internal interface CloseListener {
    fun onClose()
}

internal  interface PlayableViewLoadCallback {
    fun didLoad()
    fun didFail(errorCode: Int)
}

internal  interface PlayableViewPlaybackCallback {
    fun didFail(errorCode: Int)
    fun handleNativeAPI(message: String)
    fun didNotifyClose()
}

internal enum class PlayableViewStatus {
    NONE, LOADING, LOADED, PLAYING, FAILED_TO_LOAD, FAILED_TO_PLAY
}

internal class PlayableView(context: Context, val webView: WebView) : WebView(context) {
    var loadCallback: PlayableViewLoadCallback? = null
    var playbackCallback: PlayableViewPlaybackCallback? = null
    var requestNativeApiEventbackId: String = ""
    var status: PlayableViewStatus = PlayableViewStatus.NONE
    private var unzipResourceRoot: String? = null
    var notifyPlayableClosedEventbackId = ""
    private var listener: CloseListener? = null
    var bringToBackListener: (() -> Unit)? = null
    var storeOpenListener:  (() -> Unit)? = null
    var storeCloseEventbackId = ""
    val playableEventBackIds: HashMap<String, HashMap<String, String>> = HashMap()

    private val fileDirectory: String? = null
    private var _indexHtmlPath: String? = null

    init {
        // Configure WebView settings
        // You can set webViewClient and handle URL loading, script evaluation, etc.
        settings.javaScriptEnabled = true
        settings.allowFileAccess = true
        getSettings().setJavaScriptCanOpenWindowsAutomatically(true)
        setBackgroundColor(Color.TRANSPARENT)
        getSettings().domStorageEnabled = true
        getSettings().setMediaPlaybackRequiresUserGesture(false);

        val _webChromeClient: WebChromeClient = object : WebChromeClient() {
            private val TAG = "WebChromeClient"
            override fun onConsoleMessage(consoleMessage: ConsoleMessage): Boolean {
                Log.d("CONSOLE", "\ncall url: ${consoleMessage.message()}")
                return super.onConsoleMessage(consoleMessage)
            }

            override fun onCloseWindow(window: WebView) {
            }
        }

        this.webChromeClient = _webChromeClient
        this.webViewClient = object : WebViewClient() {

            @RequiresApi(Build.VERSION_CODES.KITKAT)

            override fun onPageStarted(view: WebView?, url: String?, favicon: Bitmap?) {
                super.onPageStarted(view, url, favicon)
            }

            @RequiresApi(Build.VERSION_CODES.KITKAT)
            override fun onPageFinished(view: WebView?, url: String?) {
                super.onPageFinished(view, url);
            }

            @RequiresApi(Build.VERSION_CODES.LOLLIPOP)
            override fun shouldOverrideUrlLoading(
                view: WebView?,
                request: WebResourceRequest?
            ): Boolean {

                val url = request!!.url.toString()
                Log.v("CONSOLE", "call url: $url")
                Log.d("CONSOLE", "call url: $url")
                if (!url.startsWith("native://")) return false

                val apiUrl = Uri.parse(url)

                evaluateScript(url)
                return false

            }
        }
    }

    fun onPlayableClosed() {
        listener?.onClose()
    }

    fun setListener(listener: CloseListener) {
        this.listener = listener
    }

    fun loadResource(url: URL) {
        val outputDirectory: String = context.filesDir.absolutePath + "/output/"
        var canonicalPathDir: String

        try {
            val outputDirFile = File(outputDirectory)
            canonicalPathDir = outputDirFile.canonicalPath
            if (outputDirFile.exists()) {
                outputDirFile.deleteRecursively() // safer to use deleteRecursively
            }
            outputDirFile.mkdirs()

            val buffer = ByteArray(1024)
            val inputStream: InputStream = url.openStream()
            val zipInputStream = ZipInputStream(BufferedInputStream(inputStream))
            val htmlFiles: MutableList<String> = ArrayList()

            var zipEntry: ZipEntry?
            while (zipInputStream.nextEntry.also { zipEntry = it } != null) {
                val zipEntryName = zipEntry!!.name
                val targetPath = outputDirectory + zipEntryName
                if (zipEntry!!.isDirectory) {
                    continue
                }
                val fileEntry = File(targetPath)
                val canonicalPath = fileEntry.canonicalPath
                if (!canonicalPath.startsWith(canonicalPathDir)) {
                    throw SecurityException("Potential Zip Slip attack detected.")
                }
                val directoryEntry = File(fileEntry.parent)
                if (!directoryEntry.exists()) {
                    directoryEntry.mkdirs()
                }
                fileEntry.createNewFile()
                if (zipEntryName.contains(".html")) {
                    htmlFiles.add(targetPath)
                }
                val outputStream = FileOutputStream(targetPath)
                var count: Int
                while (zipInputStream.read(buffer).also { count = it } != -1) {
                    outputStream.write(buffer, 0, count)
                }
                outputStream.flush()
                outputStream.close()
                zipInputStream.closeEntry()
            }

            if (htmlFiles.size == 1) {
                _indexHtmlPath = "file://" + htmlFiles[0]
            } else {
                var targetPath: String? = null
                for (path in htmlFiles) {
                    if (path.contains("index.html")) {
                        targetPath = path
                        break
                    }
                }
                if (targetPath != null) {
                    _indexHtmlPath = "file://$targetPath"
                }
            }
            if (_indexHtmlPath == null) throw Exception("unzip failure: index.html not found")

            zipInputStream.close()
        } catch (e: Exception) {
            e.printStackTrace() // Log the exception
            throw e // Re-throw the exception if needed
        }
    }

    fun start() {
        // Start loading or playing the content
        this.loadUrl(_indexHtmlPath.toString())
    }
    fun evaluateScript(result: String) {
        // Escape the result string
        val escapedResult = JSONObject.quote(result)
        val error = "" // Assuming error is an empty string for simplicity
//        val script = "window.miraibox.eventback($requestNativeApiEventbackId,\"native://loadAdInfo/{\\\"__callbackId\\\":\\\"0\\\"}\",)"
        val script = "window.miraibox.eventback($requestNativeApiEventbackId, $escapedResult, $error)"
        // Evaluate the JavaScript in the WebView
        webView.evaluateJavascript(script, ValueCallback<String> { value ->
            // Handle the result of the JavaScript execution
            if (value != null) {
                // Process the result (it will be a JSON string or "null")
                println("JavaScript execution result: $value")
            } else {
                println("JavaScript execution returned null")
            }
        })
    }

    fun evaluateSelfScript(callbackId: String, script: String){
        this.callNativeCallback(callbackId, script)
    }

    fun callNativeCallback(callbackId: String?, arg: String?) {
        this.evaluateJavascript("javascript:$arg;", null)
    }
    fun setRequestNativeApiEventBackId(requestNativeApiEventbackId: String) {
        this.requestNativeApiEventbackId = requestNativeApiEventbackId
    }

    fun setnotifyPlayableClosedEventbackId(notifyPlayableClosedEventbackId: String) {
        this.notifyPlayableClosedEventbackId = notifyPlayableClosedEventbackId
    }

    fun bringToBack() {
        bringToBackListener?.invoke()
    }

    fun onStoreOpened() {
        storeOpenListener?.invoke()
    }

    fun setEventBackIds(videoId: String, eventBackId: String, eventName: String) {
        if(playableEventBackIds.containsKey(videoId))
        {
            var hash = playableEventBackIds[videoId]
            hash?.set(eventName, eventBackId)
        }
        else {

            var hash:HashMap<String, String> = HashMap()
            hash.set(eventName, eventBackId)
            playableEventBackIds.set(videoId, hash)
        }
    }

    fun getEventBackId(videoId: String, eventName: String): String {
        return playableEventBackIds[videoId]?.getValue(eventName) ?: ""
    }
}