package jp.maio.sdk.android.v2.rewarded

import jp.maio.sdk.android.v2.errorcode.ErrorCode
import jp.maio.sdk.android.v2.rewarddata.RewardData

interface IRewardedShowCallback {
    fun opened(rewarded: Rewarded) {}
    fun closed(rewarded: Rewarded) {}
    fun clicked(rewarded: Rewarded) {}
    fun rewarded(rewarded: Rewarded, rewardData: RewardData) {}
    fun failed(rewarded: Rewarded, errorCode: Int) {}
}
