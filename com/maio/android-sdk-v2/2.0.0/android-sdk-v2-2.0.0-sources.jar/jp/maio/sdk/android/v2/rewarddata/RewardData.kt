package jp.maio.sdk.android.v2.rewarddata

data class RewardData constructor(
    val value: String
) {
    override fun toString() = String.format(
        "%s",
        value
    )
}
