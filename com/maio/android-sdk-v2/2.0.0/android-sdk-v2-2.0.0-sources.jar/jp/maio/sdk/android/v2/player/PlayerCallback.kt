package jp.maio.sdk.android.v2.player

import jp.maio.sdk.android.v2.errorcode.ErrorCode
import jp.maio.sdk.android.v2.rewarddata.RewardData

internal interface IPlayerCallback {
    fun loaded()
    fun opened()
    fun closed()
    fun rewarded(rewardData: RewardData)
    fun clicked()
    fun failed(errorCode: ErrorCode)
}