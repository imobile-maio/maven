package jp.maio.sdk.android.v2.fullscreenad

import AndroidVersionChecker
import android.content.Context
import jp.maio.sdk.android.v2.errorcode.ErrorCode
import jp.maio.sdk.android.v2.player.IPlayer
import jp.maio.sdk.android.v2.player.IPlayerCallback
import jp.maio.sdk.android.v2.player.Player
import jp.maio.sdk.android.v2.request.MaioRequest
import jp.maio.sdk.android.v2.rewarddata.RewardData
import java.net.URL

internal interface IFullScreenAd {
    val isReady: Boolean
    val isShowing: Boolean
    val url: URL
    val player: IPlayer
    fun show(context: Context, callback: IFullScreenAdShowCallback?)
    fun loadAd(context: Context, request:MaioRequest)
    var loadCallback: IFullScreenAdLoadCallback
    var showCallback: IFullScreenAdShowCallback?
}

internal class FullScreenAd(val request: MaioRequest) : IFullScreenAd, IPlayerCallback {
    override var isReady: Boolean = false
    override var isShowing: Boolean = false
    override lateinit var player: IPlayer
    override lateinit var loadCallback: IFullScreenAdLoadCallback
    override var showCallback: IFullScreenAdShowCallback? = null
    override val url: URL = URL("https://res-creatives.maio.jp/maio-ad/v1/platform/android/android.html")

    override fun show(context: Context, callback: IFullScreenAdShowCallback?) {
        showCallback = callback!!
        if(!isReady) {
            failed(ErrorCode.notReadyYet)
            return
        }

        if(isShowing) {
            failed(ErrorCode.alreadyShown)
            return
        }

        player.present(context, callback)
        isShowing = true
    }
/*
    companion object {
        fun loadAd(
            request: MaioRequest,
            callback: IFullScreenAdLoadCallback,
            context: Context
        ): FullScreenAd {

            var fullScreenAd = FullScreenAd(request)
            fullScreenAd.loadCallback = callback
            fullScreenAd.loadAd(context, request)
            return fullScreenAd
        }
    }
*/
    override fun loadAd(context: Context, request: MaioRequest) {
        if(request.zoneId.isNullOrEmpty()) {
            failed(ErrorCode.zoneNotFound)
            return
        }

        if (!AndroidVersionChecker.isAndroidVersionSupported()) {
            failed(ErrorCode.unsupportedOsVer)
            return
        }

        if (NetworkUtil.isNetworkAvailable(context)) {
            player = Player(context, this)
            player.load(request, loadCallback, this)
        }
        else {
            failed(ErrorCode.noNetwork)
        }
    }

    override fun loaded() {
        isReady = true
        loadCallback?.loaded()
    }

    override fun opened() {
        showCallback?.opened()
    }

    override fun clicked() {
        showCallback?.clicked()
    }

    override fun closed() {
        showCallback?.closed()
    }
    override fun rewarded(rewardData: RewardData) {
        showCallback?.rewarded(rewardData)
    }

    override fun failed(errorCode: ErrorCode) {
        if (errorCode.value >= 10000 && errorCode.value < 20000) {
            loadCallback?.failed(errorCode)
        }
        else if(errorCode.value >= 20000 && errorCode.value < 30000 && showCallback != null) {
            showCallback?.failed(errorCode)
        }
        else if(!isReady && errorCode.value == 0)
        {
            loadCallback?.failed(errorCode)
        }
        else if(!isShowing && errorCode.value == 0)
        {
            showCallback?.failed(errorCode)
        }
        else{
            loadCallback?.failed(errorCode)
        }
    }


}