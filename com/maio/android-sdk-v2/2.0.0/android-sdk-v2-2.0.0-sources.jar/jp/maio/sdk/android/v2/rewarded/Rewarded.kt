package jp.maio.sdk.android.v2.rewarded

import android.content.Context
import jp.maio.sdk.android.v2.errorcode.ErrorCode
import jp.maio.sdk.android.v2.fullscreenad.FullScreenAd
import jp.maio.sdk.android.v2.fullscreenad.IFullScreenAd
import jp.maio.sdk.android.v2.fullscreenad.IFullScreenAdLoadCallback
import jp.maio.sdk.android.v2.fullscreenad.IFullScreenAdShowCallback
import jp.maio.sdk.android.v2.request.MaioRequest

import jp.maio.sdk.android.v2.rewarddata.RewardData

internal interface IRewarded {
    fun show(context: Context, callback: IRewardedShowCallback?)
}

class Rewarded internal constructor(
    private val fullScreenAd: IFullScreenAd,
    private val rewardedLoadCallback: IRewardedLoadCallback
) : IRewarded {

    init {
        val loadCallback = FullscreenAdLoadCallbackRewardedLoadCallbackAdapter(this)
        loadCallback.destination = rewardedLoadCallback
        fullScreenAd.loadCallback = loadCallback
    }

    companion object {
        @JvmStatic
        fun loadAd(
            request: MaioRequest,
            context: Context,
            callback: IRewardedLoadCallback
        ): Rewarded {

            var fullScreenAd: IFullScreenAd = FullScreenAd(request)
            var maioRewarded = Rewarded(fullScreenAd, callback)
            fullScreenAd.loadAd(context, request)
            return maioRewarded
        }
    }

    private val isReady: Boolean get() = fullScreenAd.isReady

    override fun show(context: Context, callback: IRewardedShowCallback?) {
        val showCallback = FullscreenAdShowCallbackRewardedShowCallbackAdapter(this)
        showCallback.destination = callback
        fullScreenAd.show(context, showCallback)
    }
}

internal class FullscreenAdLoadCallbackRewardedLoadCallbackAdapter constructor(val rewarded: Rewarded) : IFullScreenAdLoadCallback {
    var destination: IRewardedLoadCallback? = null
    override fun loaded() {
        destination?.loaded(rewarded)
    }

    override fun failed(errorCode: ErrorCode) {
        destination?.failed(rewarded, errorCode.value)
    }
}

internal class FullscreenAdShowCallbackRewardedShowCallbackAdapter constructor(val rewarded: Rewarded): IFullScreenAdShowCallback {
    var destination: IRewardedShowCallback? = null
    override fun opened() {
        destination?.opened(rewarded)
    }

    override fun closed() {
        destination?.closed(rewarded)
    }

    override fun clicked() {
        destination?.clicked(rewarded)
    }

    override fun rewarded(rewardData: RewardData) {
        destination?.rewarded(rewarded, rewardData)
    }

    override fun failed(errorCode: ErrorCode) {
        destination?.failed(rewarded, errorCode.value)
    }
}

