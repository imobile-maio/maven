package jp.maio.sdk.android.v2.errorcode

enum class ErrorCode(val value: Int) {
    unknown(0),

    // ネットワークが見つからなかった
    noNetwork(10100),

    // 接続したがタイムアウトが発生した
    networkTimeout(10200),

    // ネットワーク接続したが処理中に切断された
    abortedDownload(10300),

    // サーバーから正しくないレスポンスが帰ってきた
    invalidResponse(10400),

    // 存在しないゾーンが指定された
    zoneNotFound(10500),

    // 有効でないゾーンが指定された(無効ゾーン、無効メディアなど)
    unavailableZone(10600),

    // 表示可能な広告が存在しない
    noFill(10700),

    // `MaioRequest` が `nil` だった
    nullArgMaioRequest(10800),

    // 動画を保存できなかったときなど
    diskSpaceNotEnough(10900),

    // 未対応の OS バージョン
    unsupportedOsVer(11000),

    // 広告の期限が切れた
    expired(20100),

    // ロードが完了する前に呼ばれた
    notReadyYet(20200),

    // `show()` は既に呼ばれている
    alreadyShown(20300),

    // 再生中のエラー。クリエイティブ要因の可能性もあるため問い合わせさせる前提
    failedPlayback(20400),

    // `ViewContext` が `null` だった
    nullArgViewContext(20500);
    companion object {
        fun fromInt(value: Int): ErrorCode {
            return values().find { it.value == value } ?: unknown
        }
    }
}
