package jp.maio.sdk.android.v2.device

internal enum class OsType {
    android,
    ios
}