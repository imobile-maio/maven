package jp.maio.sdk.android.v2.device

internal interface IDevice {
    val deviceName: String
    val deviceBrand: String
    val osVersion: String
    val language: String
    val ifa: String?
    val carrier: Array<ICarrier>
    val displayWidth: Int
    val displayHeight: Int
    val displayResolution: Float
    val audio: Array<IAudio>
    val network: NetworkConnectionType
    val osType: OsType
}

internal class Device constructor(
    build: IBuild,
    carrier: Array<ICarrier>,
    display: IDisplay,
    ifa: String,
    audio: Array<IAudio>,
    network: NetworkConnectionType
) : IDevice {
    override val deviceName: String = build.deviceName
    override val deviceBrand: String = build.deviceBrand
    override val osVersion: String = build.osVersion
    override val language: String = build.language
    override val ifa: String = ifa
    override val carrier: Array<ICarrier> = carrier
    override val displayWidth: Int = display.displayWidth
    override val displayHeight: Int = display.displayHeight
    override val displayResolution: Float = display.displayResolution
    override val audio: Array<IAudio>  = audio
    override val network: NetworkConnectionType = network
    override val osType: OsType = OsType.android

    override fun toString(): String {
        return "DEVICE \n\n" +
                "deviceBrand='${deviceBrand}'\n" +
                "osVersion=${osVersion}\n" +
                "language=${language}\n" +
                "ifa=${ifa}\n" +
                "carrierName=${carrier[0]?.carrierName}\n" +
                "mcc=${carrier[0]?.mcc}\n" +
                "mnc=${carrier[0]?.mnc}\n" +
                "displayWidth=${displayWidth}\n" +
                "displayHeight=${displayHeight}\n" +
                "displayResolution=${displayResolution}\n" +
                "audioPorts=${audio.joinToString (separator = ",") { it -> "${it.value}" }}\n" +
                "networkConnectionType=${network}\n" +
                "osType=${osType}\n"
    }
}

internal interface IDeviceFactory {
    val device: IDevice
}

internal class DeviceFactory(
    private val build: IBuildProvider,
    private val display: IDisplayProvider,
    private val ifa: IIfaProvider,
    private val carrier: ICarrierProvider,
    private val audio: IAudioProvider,
    private val network: INetworkConnectionProvider
) : IDeviceFactory {

    override val device: IDevice
        get(): IDevice {
            return Device(
                build.build,
                carrier.carrier,
                display.display,
                ifa.ifa,
                audio.audio,
                network.networkType
            )
        }
}