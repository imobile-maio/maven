package jp.maio.sdk.android.v2.interstitial

import jp.maio.sdk.android.v2.errorcode.ErrorCode

interface IInterstitialShowCallback {
    fun opened(interstitial: Interstitial) {}
    fun closed(interstitial: Interstitial) {}
    fun clicked(interstitial: Interstitial) {}
    fun failed(interstitial: Interstitial, errorCode: Int) {}
}