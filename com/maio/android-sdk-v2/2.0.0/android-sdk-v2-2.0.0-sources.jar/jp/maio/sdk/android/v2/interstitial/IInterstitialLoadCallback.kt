package jp.maio.sdk.android.v2.interstitial

import jp.maio.sdk.android.v2.errorcode.ErrorCode

interface IInterstitialLoadCallback {
    fun loaded(interstitial: Interstitial) {}
    fun failed(interstitial: Interstitial, errorCode: Int) {}
}