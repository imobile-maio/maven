package jp.maio.sdk.android.v2

data class Version private constructor(
    val major: Int = 2,
    val minor: Int = 0,
    val patch: Int = 0,
    val preRelease: String = ""
) {
    override fun toString() = String.format(
        "%s.%s.%s%s",
        major,
        minor,
        patch,
        (if (preRelease == "") preRelease else "-$preRelease")
    )
    companion object {
        val instance = Version()
    }
}