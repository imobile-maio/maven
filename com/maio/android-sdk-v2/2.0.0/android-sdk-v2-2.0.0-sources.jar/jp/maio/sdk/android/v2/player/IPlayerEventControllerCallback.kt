package jp.maio.sdk.android.v2.player

import jp.maio.sdk.android.v2.errorcode.ErrorCode
import jp.maio.sdk.android.v2.rewarddata.RewardData
import java.net.URL

internal interface IPlayerEventControllerCallback {
    fun updateSecondForPresentForceCloseView(second: Float)
    fun bringToFrontPlayer()

    //video controller
    fun loadVideo(url: URL)
    fun playVideo()
    fun pauseVideo()
    fun rewindVideo()

    //playable controller
    fun loadPlayable(url: URL)
    fun startPlayable()
    fun bringToFrontPlayable()
    fun evaluateScriptPlayable(script: String)

    //event callback
    fun loaded()
    fun rewarded(rewardData: RewardData)
    fun clicked()
    fun failed(errorCode: ErrorCode)
}