package jp.maio.sdk.android.v2

import android.content.Context

interface IContextWrapper {
    val getContext: Context
    val getFileDirectory: String
}

class ContextWrapper(val context: Context) : IContextWrapper {
    override val getContext = context
    override val getFileDirectory: String = context.filesDir.absolutePath;
}