package jp.maio.sdk.android.v2.advideoview;

import android.content.Context
import android.media.MediaPlayer;
import android.net.Uri
import android.os.Handler
import android.os.Looper
import android.webkit.WebView
import android.widget.VideoView
import jp.maio.sdk.android.v2.player.CloseListener
import java.net.URL
import java.util.Timer
import java.util.TimerTask

interface CloseListener {
    fun onClose()
}
interface ErrorListener {
    fun onError()
}


internal interface IVideoViewWrapper {
    fun play()

    fun load(url: URL, adVideoViewCallback: IAdVideoViewCallback)

    fun isPlaying(): Boolean

    fun currentPosition(): Int

    fun pause()

    fun seekTo(seconds: Int)

    fun stopPlayback()
}

internal class VideoViewWrapper(context: Context?, webView: WebView) : VideoView(context), MediaPlayer.OnPreparedListener,
    MediaPlayer.OnCompletionListener, MediaPlayer.OnErrorListener,
    IVideoViewWrapper {

    private lateinit var adVideoViewCallback: IAdVideoViewCallback
    val videoEventBackIds: HashMap<String, HashMap<String, String>> = HashMap()
    var displayDuration: Int = 0
    var timer: Timer = Timer()
    var onStartListener: (() -> Unit)? = null
    var _mediaPlayer: MediaPlayer? = null
    var playing = false
    var playCount = 0
    var finished = false
    val webView: WebView = webView
    var _lastPosition = 0
    private var closeListener: CloseListener? = null
    var storeOpenListener:  (() -> Unit)? = null
    var storeCloseEventbackId = ""
    private var errorListener: ErrorListener? = null
    private var isPaused: Boolean = false

    var defaultMute = false

    //動画の再生時間 + 5秒がタイムアウト時間になる
    private var extraTime: Long = 5000
    private var totalDuration: Long = 0
    private var remainingTime: Long = 0

    private val handler = Handler(Looper.getMainLooper())
    private var timeoutRunnable: Runnable? = null

    init {
        setOnPreparedListener(this)
        setOnCompletionListener(this)
        setOnErrorListener(this)
    }

    fun onAdCompletion() {
        playing = false
        this.stopPlayback();
        this.seekTo(0)
        videoEnd();
    }
    
    fun onVideoClosed() {
        closeListener?.onClose()
    }

    fun setListener(listener: CloseListener) {
        this.closeListener = listener
    }

    fun setListener(listener: ErrorListener) {
        this.errorListener = listener
    }

    fun setDefaultMuted() {
        defaultMute = true
    }

    override fun load(url: URL, adVideoViewCallback: IAdVideoViewCallback) {
        this.adVideoViewCallback = adVideoViewCallback
        var uri = Uri.parse(url.toString())
        super.setVideoURI(uri)
    }

    override fun start() {
        onStartListener?.invoke()
        super.start()
        if (playCount == 0) {
            seekTo(duration)
            seekTo(0)
        }
        playCount++
        finished = true
        playing = true

        if (duration > 0) {
            timeoutRunnable = Runnable {
                if (this.isPlaying) {
                    onAdCompletion()
                }
            }
            handler.postDelayed(timeoutRunnable!!, totalDuration)
        }
    }

    override fun onCompletion(p0: MediaPlayer?) {
        onAdCompletion()
    }

    fun videoPlay() {
        val eventId:String = getEventBackId("1", "onPlayed")
        val error = ""
        val result = "1"
        webView.evaluateJavascript(
            "window.miraibox.eventback( $eventId, $result, $error)",
            null
        );
    }

    fun videoEnd() {
        val eventId:String = getEventBackId("1", "onEnded")
        val error = ""
        val result = "1"
        webView.evaluateJavascript(
            "window.miraibox.eventback( $eventId, $result, $error)",
            null
        );
    }

    fun videoError() {
        val eventId:String = getEventBackId("1", "onFailed")
        val error = ""
        val result = "1"
        webView.evaluateJavascript(
            "window.miraibox.eventback( $eventId, $result, $error)",
            null
        );
    }

    override fun onError(p0: MediaPlayer?, p1: Int, p2: Int): Boolean {
        videoError()
        errorListener?.onError()
        return true
    }

    override fun pause() {
        super.pause()
        _lastPosition = currentPosition
        isPaused = true
        //handlerは一時停止できないので、バックグラウンドの時に破棄します
        if (timeoutRunnable != null) {
            handler.removeCallbacks(timeoutRunnable!!)
            //残り時間再計算
            remainingTime = currentPosition + extraTime
        }

    }

    fun resumeVideo() {
        seekTo(_lastPosition)
        start()
        //一時停止の場合に残り時間でhandler再設定する
        if (isPaused) {
            isPaused = false
            handler.postDelayed(timeoutRunnable!!, remainingTime)
        }
    }

    override fun isPlaying(): Boolean {
        return playing
    }

    override fun onPrepared(mediaPlayer: MediaPlayer?) {
        _mediaPlayer = mediaPlayer
        displayDuration = mediaPlayer!!.getDuration() / 1000
        totalDuration = mediaPlayer.duration + extraTime
        if(defaultMute) {
            mute()
        }
    }

    fun onStoreOpened() {
        storeOpenListener?.invoke()
    }

    override fun play() {
        super.start()
    }

    override fun currentPosition(): Int {
        return currentPosition
    }

    fun setEventBackIds(videoId: String, eventBackId: String, eventName: String) {
        if(videoEventBackIds.containsKey(videoId))
        {
            var hash = videoEventBackIds[videoId]
            hash?.set(eventName, eventBackId)
        }
        else {

            var hash:HashMap<String, String> = HashMap()
            hash.set(eventName, eventBackId)
            videoEventBackIds.set(videoId, hash)
        }
    }

    fun getEventBackId(videoId: String, eventName: String): String {
        return videoEventBackIds[videoId]?.getValue(eventName) ?: ""
    }

    fun startTimer(task: TimerTask) {
        timer.schedule(task ,0, 200)
    }

    fun mute() {
        try {
            setVolume(0)
        } catch (e: Exception) {

        }
    }

    fun unmute() {
        try {
            setVolume(100)
        } catch (e: Exception) {

        }
    }

    fun setVolume(amount: Int) {
        try {
            val max = 100
            val numerator: Double = if (max - amount > 0) Math.log((max - amount).toDouble()) else 0.0
            val volume = (1 - numerator / Math.log(max.toDouble())).toFloat()
            _mediaPlayer!!.setVolume(volume, volume)
        } catch (e: java.lang.Exception) {

        }
    }
}
