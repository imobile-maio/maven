package jp.maio.sdk.android.v2.appinformation

import android.annotation.TargetApi
import android.content.pm.PackageInfo
import android.content.pm.PackageManager
import android.os.Build
import jp.maio.sdk.android.v2.IContextWrapper

internal interface IPackageMgr {
    val version: String
    val bundleName: String
}

internal class PackageMgr(
    override val version: String,
    override val bundleName: String
) : IPackageMgr {}


internal interface IPackageMgrProvider {
    val packageMgr: IPackageMgr
}

@TargetApi(Build.VERSION_CODES.P)
internal class PackageMgrProvider constructor(contextWrapper: IContextWrapper) :
    IPackageMgrProvider {
    var version: String = "0"
    var bundleName: String = ""

    init {

        val pm: PackageManager = contextWrapper.getContext.packageManager
        try {
            val packageInfo: PackageInfo =
                pm.getPackageInfo(contextWrapper.getContext.packageName, 0)
            version = packageInfo.longVersionCode.toString()
        } catch (e: PackageManager.NameNotFoundException) {
        }

        bundleName = contextWrapper.getContext.packageName
    }

    override var packageMgr: IPackageMgr = PackageMgr(
        version,
        bundleName
    )
}