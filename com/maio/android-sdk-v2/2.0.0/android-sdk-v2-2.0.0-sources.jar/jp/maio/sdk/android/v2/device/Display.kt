package jp.maio.sdk.android.v2.device

import android.content.Context
import android.content.res.Configuration
import android.util.DisplayMetrics
import android.view.WindowManager
import jp.maio.sdk.android.v2.IContextWrapper

internal interface IDisplay {
    val displayWidth: Int
    val displayHeight: Int
    val displayResolution: Float
}

internal class Display(
    override val displayWidth: Int,
    override val displayHeight: Int,
    override val displayResolution: Float
) : IDisplay {}

internal interface IDisplayProvider {
    val display: IDisplay
}

internal class DisplayProvider(contextWrapper: IContextWrapper) : IDisplayProvider {
    var displayWidth: Int = 0
    var displayHeight: Int = 0
    var displayResolution: Float = 0.0f

    init {
        val metrics = getDisplayMetrics(contextWrapper)

        val rotation = getDisplayOrientation(contextWrapper)

        if (rotation == Configuration.ORIENTATION_LANDSCAPE) {
            this.displayHeight = metrics.heightPixels
            this.displayWidth = metrics.widthPixels
        } else {
            displayWidth = metrics.widthPixels
            displayHeight = metrics.heightPixels
        }
        displayResolution = metrics.density
    }

    override val display: IDisplay = Display(displayWidth, displayHeight, displayResolution)

    private fun getDisplayMetrics(contextWrapper: IContextWrapper): DisplayMetrics {
        val metrics = DisplayMetrics()
        (contextWrapper.getContext.getSystemService(Context.WINDOW_SERVICE) as WindowManager).defaultDisplay.getMetrics(
            metrics
        )
        return metrics
    }

    private fun getDisplayOrientation(contextWrapper: IContextWrapper): Int {
        return contextWrapper.getContext.resources.configuration.orientation
    }
}