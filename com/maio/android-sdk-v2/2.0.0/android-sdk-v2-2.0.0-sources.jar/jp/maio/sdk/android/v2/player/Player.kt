package jp.maio.sdk.android.v2.player

import android.content.Context
import android.webkit.WebView
import jp.maio.sdk.android.v2.advideoview.IAdVideoView
import jp.maio.sdk.android.v2.advideoview.IVideoViewWrapper
import jp.maio.sdk.android.v2.advideoview.VideoViewWrapper
import jp.maio.sdk.android.v2.errorcode.ErrorCode
import jp.maio.sdk.android.v2.fullscreenad.IFullScreenAdLoadCallback
import jp.maio.sdk.android.v2.fullscreenad.IFullScreenAdShowCallback
import jp.maio.sdk.android.v2.request.MaioRequest
import jp.maio.sdk.android.v2.rewarddata.RewardData
import java.net.URL

internal interface IPlayer {
    fun load(request: MaioRequest, loadCallback:IFullScreenAdLoadCallback,callbacks:IPlayerCallback)
    fun present(context: Context,  showCallback: IFullScreenAdShowCallback)
    val playerCallback: IPlayerCallback
    val playerEventController: IPlayerEventController
    val adVideoView: IAdVideoView
}

internal class Player(context: Context, callback: IPlayerCallback) : IPlayer, IPlayerEventControllerCallback {
    val webView: WebView
    val videoView: IVideoViewWrapper
    override var playerEventController: IPlayerEventController
    override lateinit var playerCallback:IPlayerCallback
    val playableView: PlayableView

    override val adVideoView: IAdVideoView
        get() = TODO("Not yet implemented")

    init {
        webView = WebView(context)
        videoView = VideoViewWrapper(context, webView)
        playerEventController = PlayerEventController(context, callback)
        playableView = PlayableView(context, webView)
    }

     override fun load(request: MaioRequest, loadCallback:IFullScreenAdLoadCallback, callbacks:IPlayerCallback) {
            playerEventController.load(request, loadCallback)
    }

    override fun present(context: Context, showCallback: IFullScreenAdShowCallback) {
        playerEventController.show(showCallback)
    }

    override fun updateSecondForPresentForceCloseView(second: Float) {
        TODO("Not yet implemented")
    }

    override fun bringToFrontPlayer() {
        TODO("Not yet implemented")
    }

    override fun loadVideo(url: URL) {
        TODO("Not yet implemented")
    }

    override fun playVideo() {
        TODO("Not yet implemented")
    }

    override fun pauseVideo() {
        TODO("Not yet implemented")
    }

    override fun rewindVideo() {
        TODO("Not yet implemented")
    }

    override fun loadPlayable(url: URL) {
        playableView.loadResource(url)
    }

    override fun startPlayable() {
        TODO("Not yet implemented")
    }

    override fun bringToFrontPlayable() {
        TODO("Not yet implemented")
    }

    override fun evaluateScriptPlayable(script: String) {
        TODO("Not yet implemented")
    }

    override fun loaded() {
        TODO("Not yet implemented")
    }

    override fun rewarded(rewardData: RewardData) {
        TODO("Not yet implemented")
    }

    override fun clicked() {
        TODO("Not yet implemented")
    }

    override fun failed(errorCode: ErrorCode) {
        TODO("Not yet implemented")
    }
}

internal interface PlayerCallback {
    fun didLoad()
    fun didOpen()
    fun didClose()
    fun didReward()
    fun didClick()
    fun didFail(errorCode: Int)
}