package jp.maio.sdk.android.v2.interstitial

import android.content.Context
import jp.maio.sdk.android.v2.errorcode.ErrorCode
import jp.maio.sdk.android.v2.fullscreenad.FullScreenAd
import jp.maio.sdk.android.v2.fullscreenad.IFullScreenAd
import jp.maio.sdk.android.v2.fullscreenad.IFullScreenAdLoadCallback
import jp.maio.sdk.android.v2.fullscreenad.IFullScreenAdShowCallback
import jp.maio.sdk.android.v2.request.MaioRequest
import jp.maio.sdk.android.v2.rewarddata.RewardData

internal interface IInterstitial {
    fun show(context: Context, callback: IInterstitialShowCallback?)
}

class Interstitial internal constructor(
    private val fullScreenAd: IFullScreenAd,
    private val interstitialLoadCallback: IInterstitialLoadCallback
) : IInterstitial {

    init {
        val loadCallback = FullscreenAdLoadCallbackInterstitialLoadCallbackAdapter(this)
        loadCallback.destination = interstitialLoadCallback
        fullScreenAd.loadCallback = loadCallback
    }

    companion object {
        @JvmStatic
        fun loadAd(
            request: MaioRequest,
            context: Context,
            callback: IInterstitialLoadCallback
        ): Interstitial {

            var fullScreenAd: IFullScreenAd = FullScreenAd(request)
            var interstitial = Interstitial(fullScreenAd, callback)
            fullScreenAd.loadAd(context, request)
            return interstitial
        }
    }

    private val isReady: Boolean get() = fullScreenAd.isReady

    override fun show(context: Context, callback: IInterstitialShowCallback?) {
        val showCallback = FullscreenAdShowCallbackInterstitialShowCallbackAdapter(this)
        showCallback.destination = callback
        fullScreenAd.show(context, showCallback)
    }

}

internal class FullscreenAdLoadCallbackInterstitialLoadCallbackAdapter constructor(val interstitial: Interstitial): IFullScreenAdLoadCallback {
    var destination: IInterstitialLoadCallback? = null

    override fun loaded() {
        destination?.loaded(interstitial)
    }

    override fun failed(errorCode: ErrorCode) {
        destination?.failed(interstitial, errorCode.value)
    }
}

internal class FullscreenAdShowCallbackInterstitialShowCallbackAdapter constructor(val interstitial: Interstitial) : IFullScreenAdShowCallback {
    var destination: IInterstitialShowCallback? = null
    override fun opened() {
        destination?.opened(interstitial)
    }

    override fun closed() {
        destination?.closed(interstitial)
    }

    override fun clicked() {
        destination?.clicked(interstitial)
    }

    override fun rewarded(rewardData: RewardData) {
        //実装しない
    }

    override fun failed(errorCode: ErrorCode) {
        destination?.failed(interstitial, errorCode.value)
    }
}