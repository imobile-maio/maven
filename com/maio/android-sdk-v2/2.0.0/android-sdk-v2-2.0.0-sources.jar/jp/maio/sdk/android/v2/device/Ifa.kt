package jp.maio.sdk.android.v2.device

import com.google.android.gms.ads.identifier.AdvertisingIdClient
import com.google.android.gms.common.GooglePlayServicesNotAvailableException
import com.google.android.gms.common.GooglePlayServicesRepairableException
import jp.maio.sdk.android.v2.IContextWrapper
import java.io.IOException

internal interface IIfaProvider {
    val ifa: String
}

internal class IfaProvider(contextWrapper: IContextWrapper) : IIfaProvider {
    override var ifa: String = ""

    init {
        val advertiseringId = Thread(Runnable {
            try {
                val adInfo = AdvertisingIdClient.getAdvertisingIdInfo(contextWrapper.getContext)
                if (adInfo == null || adInfo.isLimitAdTrackingEnabled) {

                } else {
                    var id: String? = adInfo.getId()
                    if(!id.isNullOrEmpty()) {
                        ifa = id
                    }
                }
            } catch (e: IOException) {
            } catch (e: GooglePlayServicesNotAvailableException) {
            } catch (e: IllegalStateException) {
                throw e
            } catch (e: GooglePlayServicesRepairableException) {
            } catch (e: VerifyError) {
            } catch (e: NullPointerException) {
            }
        })

        advertiseringId.start()
    }
}