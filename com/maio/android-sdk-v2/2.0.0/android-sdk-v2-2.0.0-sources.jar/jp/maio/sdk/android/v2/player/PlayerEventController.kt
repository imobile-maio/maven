package jp.maio.sdk.android.v2.player

import CloseButtonView
import DisplayManger
import MetaDataUtil
import android.content.Context
import android.content.Intent
import android.content.MutableContextWrapper
import android.graphics.Bitmap
import android.graphics.Color
import android.net.Uri
import android.os.Build
import android.os.Handler
import android.os.Looper
import android.util.Log
import android.view.View
import android.webkit.*
import android.widget.VideoView
import androidx.annotation.RequiresApi
import jp.maio.sdk.android.v2.AdActivity
import jp.maio.sdk.android.v2.ContextWrapper
import jp.maio.sdk.android.v2.PlayableActivity
import jp.maio.sdk.android.v2.Version
import jp.maio.sdk.android.v2.advideoview.ErrorListener
import jp.maio.sdk.android.v2.advideoview.VideoViewStatus
import jp.maio.sdk.android.v2.advideoview.VideoViewWrapper
import jp.maio.sdk.android.v2.appinformation.AppInformation
import jp.maio.sdk.android.v2.appinformation.PackageMgrProvider
import jp.maio.sdk.android.v2.device.AudioProvider
import jp.maio.sdk.android.v2.device.BuildProvider
import jp.maio.sdk.android.v2.device.CarrierProvider
import jp.maio.sdk.android.v2.device.Device
import jp.maio.sdk.android.v2.device.DisplayProvider
import jp.maio.sdk.android.v2.device.IfaProvider
import jp.maio.sdk.android.v2.device.NetworkConnectionProvider
import jp.maio.sdk.android.v2.errorcode.ErrorCode
import jp.maio.sdk.android.v2.fullscreenad.IFullScreenAdLoadCallback
import jp.maio.sdk.android.v2.fullscreenad.IFullScreenAdShowCallback
import jp.maio.sdk.android.v2.request.MaioRequest
import jp.maio.sdk.android.v2.rewarddata.RewardData
import org.json.JSONArray
import org.json.JSONException
import org.json.JSONObject
import java.io.File
import java.net.URL
import java.util.*


internal enum class PlayeverEventControllerStatus {
    None,
    Loading,
    Loaded,
    Playing,
    Completed,
}

internal class PlayerEventController(private val context: Context, var playerCallback: IPlayerCallback) : IPlayerEventController {

var dataSource: PlayerEventControllerDataSource? = null
    var timerStarted: Boolean = false
    var updateTimeEventbackId: String = ""
    val timer = Timer("Timer")

    var isPlayable:Boolean = false
    var videoEndedEventbackId: String = ""
    var storeCloseEventbackId: String = ""
    var storeOpenEventbackId: String = ""
    var appId: String = ""
    var enterEventbackId: String = ""
    var leaveEventbackId: String = ""
    var appearEventBackId: String = ""
    var disappearEventBackId: String = ""
    var notifyPlayableClosedEventbackId = ""

    var requestNativeApiEventbackId: String = ""
    var pauseEventbackId: String = ""

    internal val playableView: PlayableView
    internal val video: VideoViewWrapper
    val web: WebView
    val closeButton: CloseButtonView
    val mutableContextWrapper: MutableContextWrapper

    lateinit var showCallback: IFullScreenAdShowCallback
    var onClosedCalled = false
    var onErrorCalled = false
    var status: PlayeverEventControllerStatus = PlayeverEventControllerStatus.None

    var videoDuration: Long = 0L
    var downloadError = false

    init {
        // Initialize the WebView and set up its client for handling script messages
        mutableContextWrapper = MutableContextWrapper(context)
        web = WebView(mutableContextWrapper)
        video = VideoViewWrapper(mutableContextWrapper, web)
        playableView = PlayableView(mutableContextWrapper, web)
        closeButton = CloseButtonView(mutableContextWrapper)

        playableView.setListener(object : CloseListener {
            override fun onClose() {
                if(!onClosedCalled) {
                    onClosedCalled = true
                    showCallback?.closed()
                }
            }
        })

        video.setListener(object : CloseListener {
            override fun onClose() {
                if(!onClosedCalled) {
                    onClosedCalled = true
                    showCallback?.closed()
                }
            }
        })

        video.setListener(object : ErrorListener {
            override fun onError() {
                if(!onErrorCalled) {
                    onErrorCalled = true
                    showCallback?.failed(ErrorCode.failedPlayback)
                }
            }
        })
    }

    override fun show(showCallback1: IFullScreenAdShowCallback) {
        this.showCallback = showCallback1
        this.showCallback?.opened()
        triggerEventback(web, enterEventbackId)
        triggerEventback(web, appearEventBackId)
        startAd()
    }

    fun openAdActivity() {
        val intent = Intent(context, AdActivity::class.java)
        intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        DisplayManger.setWebview(web)
        DisplayManger.setContext(mutableContextWrapper)
        DisplayManger.setVideoView(video)
        DisplayManger.setCloseButtonView(closeButton)
        context.startActivity(intent)
    }


    fun openPlayableActivity() {
        val intent = Intent(context, PlayableActivity::class.java)
        intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        DisplayManger.setWebview(web)
        DisplayManger.setPlayableView(playableView)
        DisplayManger.setCloseButtonView(closeButton)
        DisplayManger.setContext(mutableContextWrapper)
        context.startActivity(intent)
    }

    fun setupTimer(web: WebView, video: VideoView): TimerTask {
        return object : TimerTask() {
            override fun run() {
                Handler(Looper.getMainLooper()).post {
                    if (video != null && video.isPlaying && web != null) {
                        val elapsed: Int = video.currentPosition / 1000
                        val error = ""
                        web.evaluateJavascript(
                            "window.miraibox.eventback($updateTimeEventbackId, $elapsed, $error)",
                            null
                        )
                    }
                }
            }
        }
    }

    fun webViewSettings(web: WebView) {
        web.getSettings().setJavaScriptEnabled(true)
        web.getSettings().setJavaScriptCanOpenWindowsAutomatically(true)
        web.setBackgroundColor(Color.TRANSPARENT)
        web.getSettings().domStorageEnabled = true
    }

    override fun load(request: MaioRequest, loadCallback: IFullScreenAdLoadCallback) {
        status = PlayeverEventControllerStatus.Loading
        webViewSettings(web)
        web.loadUrl("https://res-creatives.maio.jp/maio-ad/v1/platform/android/android.html")
        webViewCallbacks(web, video, request, loadCallback)
    }

    fun startAd(web: WebView) {
        var script = "window.miraibox.startAd()"
        web.evaluateJavascript(script,null);
    }

    fun triggerEventback(web: WebView, id:String) {
        val error = ""
        val result = "1"
        web.evaluateJavascript(
            "window.miraibox.eventback( $id, $result, $error)",
            null
        );
    }

    private fun webViewCallbacks(web: WebView, video: VideoViewWrapper, maioRequest: MaioRequest,  loadCallback: IFullScreenAdLoadCallback) {
        val _webChromeClient: WebChromeClient = object : WebChromeClient() {
            private val TAG = "WebChromeClient"
            override fun onConsoleMessage(consoleMessage: ConsoleMessage): Boolean {
                Log.d("CONSOLE", "\ncall url: ${consoleMessage.message()}")
                return super.onConsoleMessage(consoleMessage)
            }

            override fun onCloseWindow(window: WebView) {
            }
        }

        web.webChromeClient = _webChromeClient
        web.webViewClient = object : WebViewClient() {

            @RequiresApi(Build.VERSION_CODES.KITKAT)

            override fun onPageStarted(view: WebView?, url: String?, favicon: Bitmap?) {
                super.onPageStarted(view, url, favicon)
            }

            @RequiresApi(Build.VERSION_CODES.KITKAT)
            override fun onPageFinished(view: WebView?, url: String?) {
                super.onPageFinished(view, url);
            }

            @RequiresApi(Build.VERSION_CODES.LOLLIPOP)
            override fun shouldOverrideUrlLoading(
                view: WebView?,
                request: WebResourceRequest?
            ): Boolean {

                val url = request!!.url.toString()
                Log.v("CONSOLE", "call url: $url")
                Log.d("CONSOLE", "call url: $url")
                if (!url.startsWith("native://")) return false

                val apiUrl = Uri.parse(url)

                val jsonArray = JSONArray(apiUrl.queryParameterNames.toString())
                val jsonObject: JSONObject = jsonArray.getJSONObject(0)

                val methodName = jsonObject.get("method")
                var callbackId: String? = jsonObject.optString("callbackId")
                var eventbackId: String? = ""
                try {
                    eventbackId = jsonObject.getJSONObject("args").getString("eventbackId")
                } catch (e: Exception) {

                }
                var result: String? = null

                when (methodName) {

                    "Miraibox.onLeave" -> {
                        leaveEventbackId = eventbackId!!
                    }

                    "Miraibox.onEnter" -> {
                        enterEventbackId = eventbackId!!
                    }

                    "Miraibox.onAppear" -> {
                        appearEventBackId = eventbackId!!
                        video.setEventBackIds("1", eventbackId, "onAppear")
                        playableView.setEventBackIds("1", eventbackId, "onAppear")
                    }

                    "Miraibox.onDisappear" -> {
                        disappearEventBackId = eventbackId!!
                        video.setEventBackIds("1", eventbackId, "onDisappear")
                        playableView.setEventBackIds("1", eventbackId, "onDisappear")
                    }

                    "Miraibox.getDevice" -> {
                        val contextWrapper = ContextWrapper(context)

                        val device = Device(
                            BuildProvider().build,
                            CarrierProvider(contextWrapper).carrier,
                            DisplayProvider(contextWrapper).display,
                            IfaProvider(contextWrapper).ifa,
                            AudioProvider(contextWrapper).audio,
                            NetworkConnectionProvider(contextWrapper).networkType
                        )

                        val deviceInfo = JSONObject(object : HashMap<String?, Any?>() {
                            init {
                                put("deviceBrand", device.deviceBrand)
                                put("deviceName", device.deviceName)
                                put("osType", device.osType.toString())
                                put("osVersion", device.osVersion)
                                put("userAgent", "userAgent")
                                put("language", device.language)
                                put("ifa", device.ifa)
                                put("networkType", device.network.toString())
                                put("displayWidth", device.displayWidth)
                                put("displayHeight", device.displayHeight)
                                put("displayResolution", device.displayResolution)
                            }
                        })

                        // Carriers
                        val carriersArray = JSONArray()
                        device.carrier.forEach { carrier ->
                            val carrierObj = JSONObject().apply {
                                put("carrierName", carrier.carrierName)
                                put("mcc", carrier.mcc)
                                put("mnc", carrier.mnc)
                                put("isUsing", carrier.isUsing)
                            }
                            carriersArray.put(carrierObj)
                        }
                        deviceInfo.put("carriers", carriersArray)

                        // Audio Ports
                        val audioPortsArray = JSONArray()
                        device.audio.forEach { audioPort ->
                            val audioPortObj = JSONObject().apply {
                                put("value", audioPort.value)
                            }
                            audioPortsArray.put(audioPortObj)
                        }
                        deviceInfo.put("audioPorts", audioPortsArray)

                        result = deviceInfo.toString()
                    }

                    "Miraibox.getSdkVersion" -> {
                        val sdkVersion =
                            Version.instance

                        val sdkVersionJson = JSONObject(object : HashMap<String?, Any?>() {
                            init {
                                put("major", sdkVersion.major)
                                put("minor", sdkVersion.minor)
                                put("patch", sdkVersion.patch)
                                put("preRelease", sdkVersion.preRelease)

                            }
                        })

                        result = sdkVersionJson.toString()
                    }

                    "Miraibox.getAdRequest" -> {
                        val requestJson = JSONObject()
                        requestJson.put("zoneId", maioRequest.zoneId)
                        requestJson.put("test", maioRequest.testMode)
                        if(!maioRequest.bidData.isNullOrEmpty()) {
                            requestJson.put("bidData", maioRequest.bidData)
                        }
                        result = requestJson.toString()
                    }

                    "Miraibox.loadVideo" -> {
                        isPlayable = false
                        result = "1"
                        val videoUrl: String
                        videoUrl = try {
                            jsonObject.getJSONObject("args").getString("videoUrl")
                        } catch (e: JSONException) {
                            return true
                        }

                        val fileName = Uri.parse(url).lastPathSegment ?: "temp_video"
                        var videoFile = File.createTempFile(fileName, ".mp4", context.cacheDir)

                        val thread = Thread(Runnable {
                            try {
                                videoFile = DownloadManager.downloadVideo(videoUrl, mutableContextWrapper, videoFile)
                            } catch (ignored: java.lang.Exception) {
                                // TODO: log error, index.html not found
                                downloadError = true

                                return@Runnable
                            }
                        })

                        thread.start()
                        thread.join()

                        if(downloadError) {
                            playerCallback.failed(ErrorCode.abortedDownload)
                            return true
                        }

                        videoDuration = MetaDataUtil.getVideoDuration(videoFile!!)
                        video.setVideoURI(Uri.fromFile(videoFile))
                    }

                    "Miraibox.loadStore" -> {
                        result = "1"
                        appId = jsonObject.getJSONObject("args").getString("appId")
                    }

                    "Store.show" -> {
                        val urlString = String.format("market://details?id=%s", appId)
                        val intent = Intent(Intent.ACTION_VIEW, Uri.parse(urlString))
                        intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                        context.startActivity(intent)
                        triggerEventback(web, storeOpenEventbackId)

                        video?.onStoreOpened()
                        playableView?.onStoreOpened()
                    }

                    "Miraibox.tracking" -> {
                        val clickUrl: String
                        clickUrl = try {
                            jsonObject.getJSONObject("args").getString("url")
                        } catch (e: JSONException) {
                            return true
                        }
                    }

                    "Miraibox.openUrl" -> {
                        val openUrl: String
                        openUrl = try {
                            jsonObject.getJSONObject("args").getString("url")

                        } catch (e: JSONException) {
                            return true
                        }

                        val intent = Intent(Intent.ACTION_VIEW, Uri.parse(openUrl))
                        intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                        context.startActivity(intent)
                        result = "1"
                    }

                    "Miraibox.showCloseButton" -> {
                        if(!isPlayable) {
                            var offset = jsonObject.getJSONObject("args").getString("offset")
                            closeButton.setOffset(offset.toInt())
                        }
                    }

                    "Miraibox.notifyReward" -> {
                        val reward: String
                        reward = try {
                            jsonObject.getJSONObject("args").getString("rewardData")
                        } catch (e: JSONException) {
                            return true
                        }
                        showCallback?.rewarded(RewardData(reward))
                    }

                    "Miraibox.notifyClicked" -> {
                        result = "1"
                        if (::showCallback.isInitialized) {
                            showCallback?.clicked()
                        }
                    }

                    "Miraibox.startAd" -> {
                        result = "1"
                    }

                    "Miraibox.exit" -> {
                        if(downloadError) {
                            return true
                        }

                        var error: String = ""
                        try {
                            error = jsonObject.getJSONObject("args").getJSONObject("error")
                                .getString("code")
                        } catch (e: Exception) {

                        }

                        video?.stopPlayback()
                        video?.setVisibility(View.GONE)
                        closeButton?.performClick()

                        if (!error.isNullOrEmpty()) {
                            playerCallback.failed(ErrorCode.fromInt(error?.toInt() ?: 0))
                        }

                        if (::showCallback.isInitialized && !onClosedCalled) {
                            onClosedCalled = true
                            showCallback.closed()
                        }

                        status = PlayeverEventControllerStatus.Completed
                    }

                    "Miraibox.ready" -> {
                        result = "1"
                        playerCallback.loaded()
                        status = PlayeverEventControllerStatus.Loaded
                    }

                    "Video.play" -> {
                        result = "1"
                        if(status == PlayeverEventControllerStatus.Loaded) {
                            video.start()
                            video.seekTo(video.duration)
                            video.seekTo(0)
                            status = PlayeverEventControllerStatus.Playing
                            openAdActivity()
                        }
                    }

                    "Video.pause" -> {
                        result = "1"
                        if(video != null && video.isPlaying()) {
                            video.pause()
                        }

                        triggerEventback(web, pauseEventbackId)
                    }

                    "Video.getDuration" -> {
                        result = (videoDuration / 1000.0).toString()
                    }

                    "Video.onPlayed" -> {
                        result = "1"
                        var eventbackId =
                            jsonObject.getJSONObject("args").getString("eventbackId")
                        var videoId =
                            jsonObject.getJSONObject("args").getJSONObject("args")
                                .getString("videoId")

                        video.setEventBackIds(videoId, eventbackId, "onPlayed")
                        val task: TimerTask = setupTimer(web, video)
                        video.startTimer(task)
                    }

                    "Video.onPaused" -> {
                        result = "1"
                        pauseEventbackId =
                            jsonObject.getJSONObject("args").getString("eventbackId")
                    }

                    "Video.onTimeUpdated" -> {
                        result = "1"
                        updateTimeEventbackId =
                            jsonObject.getJSONObject("args").getString("eventbackId")
                    }

                    "Video.onEnded" -> {
                        result = "1"
                        var eventbackId =
                            jsonObject.getJSONObject("args").getString("eventbackId")
                        var videoId =
                            jsonObject.getJSONObject("args").getJSONObject("args")
                                .getString("videoId")

                        video.setEventBackIds(videoId, eventbackId, "onEnded")
                    }

                    "Video.onFailed" -> {
                        result = "1"
                        var eventbackId =
                            jsonObject.getJSONObject("args").getString("eventbackId")
                        var videoId =
                            jsonObject.getJSONObject("args").getJSONObject("args")
                                .getString("videoId")

                        video.setEventBackIds(videoId,eventbackId, "onFailed")
                    }

                    "Video.getMuted" -> {
                        result = "1"
                    }

                    "Video.setMuted" -> {
                        result = "1"

                        val muted: String
                        muted = try {
                            jsonObject.getJSONObject("args").getString("value")
                        } catch (e: JSONException) {
                            return true
                        }

                        if(status == PlayeverEventControllerStatus.Loading) {
                            if (muted == "true") {
                                video.setDefaultMuted()
                            }
                        }
                        else {
                            if (muted == "false") {
                                video.unmute()
                            } else {
                                video.mute()
                            }
                        }
                    }

                    "Video.watchCurrentTime" -> {
                        result = "1"
                    }

                    "Store.onOpened" -> {
                        result = "1"
                        storeOpenEventbackId =
                            jsonObject.getJSONObject("args").getString("eventbackId")
                    }

                    "Store.onClosed" -> {
                        result = "1"
                        storeCloseEventbackId =
                            jsonObject.getJSONObject("args").getString("eventbackId")
                        video?.storeCloseEventbackId = storeCloseEventbackId
                        playableView?.storeCloseEventbackId = storeCloseEventbackId
                    }

                    "Miraibox.loadPlayable" -> {
                        isPlayable = true
                        var url = jsonObject.getJSONObject("args").getString("zipUrl")

                        val thread = Thread(Runnable {
                            try {
                                playableView.loadResource(URL(url))
                            } catch (ignored: java.lang.Exception) {
                                // TODO: log error, index.html not found
                                return@Runnable
                            }
                        })
                        thread.start()
                        thread.join()
                        result = "1"
                    }

                    "Playable.start" -> {
                        result = "1"
                        playableView.start()
                        openPlayableActivity()
                    }

                    "Playable.bringToFront" -> {
                        result = "1"
                    }

                    "Playable.bringToBack" -> {
                        result = "1"
                        playableView.bringToBack()
                    }

                    "Playable.onRequestNativeAPI" -> {
                        result = "1"
                        requestNativeApiEventbackId =
                            jsonObject.getJSONObject("args").getString("eventbackId")
                        playableView.setRequestNativeApiEventBackId(requestNativeApiEventbackId)
                    }

                    "Playable.showCloseButton" -> {
                        var offset = jsonObject.getJSONObject("args").getString("offset")
                        closeButton.setOffset(offset.toInt())
                        result = "1"
                    }

                    "Playable.evaluateScript" -> {
                        result = "1"
                        val script =
                            jsonObject.getJSONObject("args").getString("script")
                        playableView.evaluateSelfScript("0", script)
                    }

                    "Playable.onNotifyClose" -> {
                        result = "1"
                        notifyPlayableClosedEventbackId =
                            jsonObject.getJSONObject("args").getString("eventbackId")
                        playableView.setnotifyPlayableClosedEventbackId(notifyPlayableClosedEventbackId)
                    }

                    "Miraibox.getApp" -> {

                        val sdkVersion =
                            Version.instance

                        val sdkVersionJson = JSONObject(object : HashMap<String?, Any?>() {
                            init {
                                put("major", sdkVersion.major)
                                put("minor", sdkVersion.minor)
                                put("patch", sdkVersion.patch)
                                put("preRelease", sdkVersion.preRelease)
                            }
                        })

                        val packageMgrProvider =
                            PackageMgrProvider(ContextWrapper(context))
                        val appInfo =
                            AppInformation(sdkVersion.toString(), packageMgrProvider.packageMgr)

                        val appInfoJson = JSONObject()
                        appInfoJson.put("bundleId", appInfo.bundleName)
                        appInfoJson.put("ver", appInfo.version)
                        appInfoJson.put("sdkVer", sdkVersionJson)

                        result = appInfoJson.toString()
                    }
                }

                if (result != null) {
                    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.KITKAT) {
                        val error = ""
                        web.evaluateJavascript(
                            "window.miraibox.callback( $callbackId, $result, $error)",
                            null
                        );
                    }
                }

                return false
            }
        }
    }

fun startAd() {
    val script = "window.miraibox.startAd()"
    evaluateJavaScript(script)
}

fun didNotifyForceClose() {
    // Implement the logic similar to iOS version
}

// ... Other methods

private fun evaluateJavaScript(script: String) {
    web.evaluateJavascript(script) { result ->
        // Handle the result of the JavaScript execution
    }
}

// Add other methods and functionalities similar to the Swift version
}

internal interface PlayerEventControllerDataSource {
    // Define data source methods similar to the Swift protocol
}

internal interface IPlayerActivityClosed {
    fun didClose()
}