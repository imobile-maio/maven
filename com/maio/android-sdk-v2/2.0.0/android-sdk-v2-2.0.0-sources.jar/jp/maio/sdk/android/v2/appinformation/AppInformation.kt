package jp.maio.sdk.android.v2.appinformation

/*
   アプリ情報
 */
internal class AppInformation constructor(override val sdkVersion: String, packageMgr: IPackageMgr) :
    IAppInformation {
    override val version: String = packageMgr.version
    override val bundleName: String = packageMgr.bundleName
}

interface IAppInformation {
    val bundleName: String
    val version: String
    val sdkVersion: String
}