package jp.maio.sdk.android.v2.fullscreenad

internal enum class FullScreenAdState {
    Loading,
    Loaded,
    Expired,
    Opening,
    Opened,
    Playback,
    Closing,
    Closed,
    Failed,
}