package jp.maio.sdk.android.v2.request

data class MaioRequest constructor(
    val zoneId: String,
    val testMode: Boolean,
    val bidData: String = ""
) {
    override fun toString() = String.format(
        "%s %s %s",
        zoneId,
        testMode,
        bidData
    )
}