import android.os.Build

internal class AndroidVersionChecker {
    companion object {
        fun isAndroidVersionSupported(): Boolean {
            // Android KitKat is API level 19
            return Build.VERSION.SDK_INT >= Build.VERSION_CODES.KITKAT
        }
    }
}