package jp.maio.sdk.android.v2

import CloseButtonView
import android.app.Activity
import android.content.Intent
import android.content.pm.ActivityInfo
import android.content.res.Configuration
import android.net.Uri
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.provider.Settings
import android.util.Log
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.view.WindowManager
import android.view.animation.AlphaAnimation
import android.webkit.WebView
import android.widget.FrameLayout
import jp.maio.sdk.android.v2.advideoview.VideoViewWrapper
import jp.maio.sdk.android.v2.player.PlayerEventController

class AdActivity : Activity() {

    private var isReturningFromStore = false
    var timerStarted: Boolean = false
    var updateTimeEventbackId: String = ""
    var videoEndedEventbackId: String = ""
    var storeOpenEventbackId: String = ""
    private lateinit var video: VideoViewWrapper
    lateinit var web: WebView
    var appId: String = ""
    internal lateinit var playerEventController: PlayerEventController
    lateinit var closeButton: CloseButtonView

    override fun onBackPressed() {}
    override fun onPause() {
        super.onPause()
        if (video != null) {
            video.pause()
        }
        triggerEventback(web, video.getEventBackId("1","onDisappear"))
    }

    override fun onResume() {
        super.onResume()
        if (video != null && video.isPlaying() === true) {
            video.resumeVideo()
        }
        if(isReturningFromStore) {
            triggerEventback(web, video.storeCloseEventbackId)
        }
        triggerEventback(web, video.getEventBackId("1","onAppear"))
    }

    override fun onConfigurationChanged(newConfig: Configuration) {
        super.onConfigurationChanged(newConfig!!)
        window.setFlags(
            WindowManager.LayoutParams.FLAG_FULLSCREEN,
            WindowManager.LayoutParams.FLAG_FULLSCREEN
        )
    }

    fun startAd(web: WebView) {
        var script = "window.miraibox.startAd()"
        web.evaluateJavascript(script, null);
    }

    fun triggerEventback(web: WebView, id: String) {
        val error = ""
        val result = "1"
        web.evaluateJavascript(
            "window.miraibox.eventback( $id, $result, $error)",
            null
        );
    }

    fun videoEnd(web: WebView) {
        val error = ""
        val result = "1"
        web.evaluateJavascript(
            "window.miraibox.eventback( $videoEndedEventbackId, $result, $error)",
            null
        );
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        web = DisplayManger.getWebview()
        video = DisplayManger.getVideoView()
        closeButton = DisplayManger.getCloseButtonView()
        startAd(web)

        video.onStartListener = {
            /*
           requestedOrientation =

               if (video.width > video.height) {
                   // 横の場合 端末の設定が自動回転かを取得(0は回転なし、1は回転あり)
                   if (Settings.System.getInt(
                           contentResolver,
                           Settings.System.ACCELEROMETER_ROTATION,
                           0
                       ) == 1
                   ) {
                       //端末の回転に合わせて回転する
                       ActivityInfo.SCREEN_ORIENTATION_SENSOR_LANDSCAPE
                   } else {
                       //固定
                       ActivityInfo.SCREEN_ORIENTATION_LANDSCAPE
                   }
               } else {
                   // 縦の場合固定
                   ActivityInfo.SCREEN_ORIENTATION_PORTRAIT
               }
*/
            //動画をスクリーンの真ん中にする
            runOnUiThread {
                val width = windowManager.defaultDisplay.width
                val height = windowManager.defaultDisplay.height
                if (video != null) {
                    video.holder.setFixedSize(width, height)

                    val lp = FrameLayout.LayoutParams(
                        ViewGroup.LayoutParams.MATCH_PARENT,
                        ViewGroup.LayoutParams.MATCH_PARENT
                    )
                    lp.gravity = Gravity.CENTER
                    video.setLayoutParams(lp)
                    video.forceLayout()
                }
            }
        }

        DisplayManger.getContext().baseContext = this

        val layout = FrameLayout(this)
        layout.id = 1
        val layoutparams = FrameLayout.LayoutParams(
            ViewGroup.LayoutParams.MATCH_PARENT,
            ViewGroup.LayoutParams.MATCH_PARENT,
            Gravity.CENTER_HORIZONTAL or Gravity.CENTER_VERTICAL
        )
        layout.layoutParams = layoutparams

        val layout2 = FrameLayout(this)
        layout2.id = 2
        val layoutparams2 = FrameLayout.LayoutParams(
            ViewGroup.LayoutParams.FILL_PARENT,
            ViewGroup.LayoutParams.FILL_PARENT
        )
        layout2.layoutParams = layoutparams2

        web.id = 2
        web.layoutParams = layoutparams

        video.id = 3
        video.layoutParams = layoutparams2
        video.keepScreenOn = true

        layout.addView(video)
        layout.addView(web)

        closeButton.id = 4
        closeButton.bringToFront()
        closeButton.setOnClickListener(View.OnClickListener {
            video.onVideoClosed()
            this.finish();
        })

        //val animation = AlphaAnimation(0f, 1f)
        //animation.duration = 1000
        layout.addView(closeButton)
        //closeButton.startAnimation(animation)
        closeButton.setVisibility(View.INVISIBLE)
        setContentView(layout)

        video.storeOpenListener = {
            isReturningFromStore = true
        }
    }

}
