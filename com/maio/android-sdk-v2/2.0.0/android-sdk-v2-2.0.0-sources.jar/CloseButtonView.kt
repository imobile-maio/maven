import android.annotation.SuppressLint
import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.drawable.BitmapDrawable
import android.os.Handler
import android.os.Looper
import android.util.Base64
import android.util.TypedValue
import android.view.Gravity
import android.widget.FrameLayout
import android.widget.ImageButton

@SuppressLint("AppCompatCustomView")
class CloseButtonView(context: Context) : ImageButton(context) {
    init {

        // 画面の 1/10 の高さをボタンのサイズにする
        val desiredSize = dipToPixels(context, 25f).toInt()
        val closeButtonBytes = Base64.decode(_closeButtonPng, Base64.DEFAULT)
        val closeButton = Bitmap.createScaledBitmap(
            BitmapFactory.decodeByteArray(
                closeButtonBytes,
                0,
                closeButtonBytes.size
            ),
            desiredSize, desiredSize,
            false
        )
        val drawable = BitmapDrawable(resources, closeButton)
        background = drawable
        val layoutParams = FrameLayout.LayoutParams(
            FrameLayout.LayoutParams.WRAP_CONTENT,
            FrameLayout.LayoutParams.WRAP_CONTENT
        )
        layoutParams.gravity = Gravity.TOP or Gravity.END
        layoutParams.setMargins(0, 20, 20, 0)
        setLayoutParams(layoutParams)
        visibility = INVISIBLE
    }

    fun setOffset(offsetTimeInSeconds: Int) {
        visibility = INVISIBLE
        // Use a handler to delay the visibility change
        Handler(Looper.getMainLooper()).postDelayed({
            visibility = VISIBLE
        }, offsetTimeInSeconds * 1000L) // Convert seconds to millisecon
    }

    companion object {
        private fun dipToPixels(context: Context, dipValue: Float): Float {
            val metrics = context.resources.displayMetrics
            return TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_DIP, dipValue, metrics)
        }

        private const val _closeButtonPng =
            "iVBORw0KGgoAAAANSUhEUgAAADgAAAA4CAYAAACohjseAAAAGXRFWHRTb2Z0d2FyZQBBZG9iZSBJbWFnZVJlYWR5ccllPAAAAxFpVFh0WE1MOmNvbS5hZG9iZS54bXAAAAAAADw/eHBhY2tldCBiZWdpbj0i77u/IiBpZD0iVzVNME1wQ2VoaUh6cmVTek5UY3prYzlkIj8+IDx4OnhtcG1ldGEgeG1sbnM6eD0iYWRvYmU6bnM6bWV0YS8iIHg6eG1wdGs9IkFkb2JlIFhNUCBDb3JlIDUuNS1jMDIxIDc5LjE1NDkxMSwgMjAxMy8xMC8yOS0xMTo0NzoxNiAgICAgICAgIj4gPHJkZjpSREYgeG1sbnM6cmRmPSJodHRwOi8vd3d3LnczLm9yZy8xOTk5LzAyLzIyLXJkZi1zeW50YXgtbnMjIj4gPHJkZjpEZXNjcmlwdGlvbiByZGY6YWJvdXQ9IiIgeG1sbnM6eG1wTU09Imh0dHA6Ly9ucy5hZG9iZS5jb20veGFwLzEuMC9tbS8iIHhtbG5zOnN0UmVmPSJodHRwOi8vbnMuYWRvYmUuY29tL3hhcC8xLjAvc1R5cGUvUmVzb3VyY2VSZWYjIiB4bWxuczp4bXA9Imh0dHA6Ly9ucy5hZG9iZS5jb20veGFwLzEuMC8iIHhtcE1NOkRvY3VtZW50SUQ9InhtcC5kaWQ6NTM2Q0RCRkIxMzNFMTFFNUFFRDY4MjU5Q0UwRjA5N0IiIHhtcE1NOkluc3RhbmNlSUQ9InhtcC5paWQ6NTM2Q0RCRkExMzNFMTFFNUFFRDY4MjU5Q0UwRjA5N0IiIHhtcDpDcmVhdG9yVG9vbD0iQWRvYmUgUGhvdG9zaG9wIENDIChXaW5kb3dzKSI+IDx4bXBNTTpEZXJpdmVkRnJvbSBzdFJlZjppbnN0YW5jZUlEPSJGQjU2RDhDMzU5NjZGQzkwNzA4RkZEQTAxOEEzRjNCRCIgc3RSZWY6ZG9jdW1lbnRJRD0iRkI1NkQ4QzM1OTY2RkM5MDcwOEZGREEwMThBM0YzQkQiLz4gPC9yZGY6RGVzY3JpcHRpb24+IDwvcmRmOlJERj4gPC94OnhtcG1ldGE+IDw/eHBhY2tldCBlbmQ9InIiPz77E+Y9AAANqUlEQVR42sxbe1CTVxbP40vIi2eAgKiIQKVU66zu+thqHaftVKuiVURrBUGLbtetM1tXtB3Rwe0/xe2MtbJWastOrbptbceCWAc7dXyxaLd0dKxFEJAiJbwhhEDIa38n3jifaZ4Y7H4zR/Ml9/H73XPuuefcexHabDbBKD4hkAmQREgEJJx93wPphjRAGiG60QLABbi9KMgSyFLIXB4hbw8Rvgj5ClIG6QgUIGEANCiBZEA2Q2YHCNd/IEWQzyCmgoICtwV37949agSJ2OuQPGZ+95+hoSGdVqttgrS2t7d3tbW19fb09AwaBgaGqT+lSiUNDw+XazSasOjoaHVMTEwsJF4mk4U49UFmvBfyDkiaHiXBBZAPIGMdXwwODurq6uquX7ly5WZDQ0M7x3FWtVotg6gUCkWQRCIRU3+suM1kMlkMBoOxq6tLDxkym82iiRMnRs+cOTM1OTl5ilwuD+X1dxeSCznjTMiTdkdCUAH5N5tn9qevr6+9qqrq8rlz536SSqWmhIQENbSjtFqtNqPRaCISA9ActGoiUvaJz3FiEJAolUopkccjEYlEQmh5oLGxsQtkuXnz5qXOmjXrqdDQ0Ghe/6cgq3bt2mVwfLFnz56AEZzCOhhPL8PDwwMXL148d+bMmWsAa0lJSdEI8YCwAUAN0KiZSPrSMJFDGxwGRgFCCmCy1dTUtKEN8YIFC6bOnTt3PgZPyYr/zAb4+s6dOwVvvfVWQAguhHwJkdFLU1NTzb9KSk4PDg3pJ02apCaAHR0dep1OZ8ToWx/KrXOcKCQkJCgqKkpFA3Tr1q0uuUymys7JeSE+Pj7FMc0hyyFfB8KLZkJKIGJ0aLlw4cI3X508+V91ZKQoLi4ulLRFDgTmZw3keoM5KyJHRFptaWnp6+rstKYtXfp7mO6zGFCaz2TuOZAjD0NwOXPVYmhm+MSJEycx32oxzxQ0j6C1AZiRabSCBVi8gOYqtKlE/xbMTwPm5WPp6enL0L+Ukcxg1uU3wamQqxCpxWIxlZSUfHr9+vU7SUlJKnIWnZ2dhkBrzZM2IyMjFeSJb9++rX/yyScn5OTkrBKLxbRUDUNmQK75Q1AFqYXEklkeOXLkxHdXr96emJiogHOxwK0bQNomeIQPyAix5CjgbMQN9fWGGTNnJq1duzadmWsr5DGI/lcOzE17x4gcfTh79uy5ysrK+jFxcUHkGWGWpDkbiAsepVCf1DdhICyXL1+uB7ZvGV7Cetylh3bjMe3rHMyh5vjx49+rVCoraRodDEKDNmhP8FsI9U0YyPIIE7BVI7ioYbgXQ17wZqISFt3HYYHWb8/LKxk2mXrhVJQIuwYe1ZzzZU4itFPC6QxIJZKwtwsLcxAw0LRqgSRQ/Ooum9hC5Owhw6lTF3T9/fpEzDvEk1jyhlySw0I86ZlnnnkOUUkY3HldcXFxKRtl/1ORqCh5bm7u4rFjx6ZggHvPnz//bVlZ2Y/O5aBNK2HCMqWor6/XE9aMjIwXGHbi8I4rE+VY4Eym2P7FiRM3MaEpxLLo9XqzK5NB9BKZlpa2Mjg4mBZ78bhx41K2bt26DkAV/pofORCqO378+FS0JYIJRixcuHB5ampqlKvyhImwEUbCSpgZj+3MEn9FcDXEHveVlpZegdcyIdJXYjmg6MQlqOnTpyczL3b/CQsL0wBolj8kaQnYtm1bFtV1CuFE1IerOoSJsBFGwkqYeTnpS64I/pn+6e/v10HltzmJhAJlMya21Z1noyzAlakR0Ly8vCx0rvDmHWkgtm/f/ityjqcT5u6uLmEjjISVMCNUdOwMvOpMMNqRrFZXV98S2GwmmAiH8iZPI3/s6FHK+XrckSTgRNJdfSK3Y8cOt+Ta0PaxY8eaPGEgjIhdJcjDTJSqsaqzIBo+wcWORjGpb4k5zgy1i7HmWD01TqnQq5s2VWhbW12SRBypeeONN1ySJHJvvvlmFpVxVZcG7k9oG6mW0RMGwoiQDhNFbDp9+nQtr4k0PsFlzDz7r1271okKFjRs9jZ3FEqlob2jQ7cJQFo9kERak4Xs/T5JIpyfn++R3KaNGyvgKXVyhcLgDQdhBWbrjRs3upGu9bFmlvAJzqF/4HIpc6ZF3QovZfHWMKUz0RqNloAQIE8kiRARI0HC6pHcxtzciva2Nl10TIyWckNvOAgrYSbFIDhp4XPi+Nt5tbW1HVSIJrAfsaY1Kjpai/ki2PjKKxXFhw8/FxsbG+FcKCIiQlNQUJDl+OyOXO6GDXbNaWJjtdQ2EfD2EFbKPOgjlNQJzytgnEJFbN/S/jQ0NPTCwVgoFSI37KvQ6CE/BD6tbsP69WehyW5XQIiYW3LQ/vqcnIpWtKGOiiLNWf3BQJgBxIpAnG9FEx4gCA3qYJ8UsQj9XahptCNAEprU5WRnn/3ll1+6fY1gyLSzs7MraIBooBya81cIe21dXT+v6UQiGOl4a7l7d5Bs3mg0jiigJmDharVfJFGmJ3vdOju5CNQdKTnKNujBumnkG42Iv6eJcMfkcL0jjfjtJCMitDA5HYL1C57mMv22A2WgQR1Md8TkSBC22ZWC6MbkTJDfodBiNgtpNB4mrQEj6xOTJ+sK9+6dS4mqpyT27b175yBD19kegpxDg4SdODjng/fNKCw8XGq+V+ih8jZ4UcX+995bi//V3kyUyux79921lBk8bL+EPRhRDX9nnAh2Ot5iNBo58j8RFfTHg/HFTm7//iwE0BpfnQyV3bdvX9aYMWMUI+2XMBN22k13JnjH8ZaUnBwKVYvdZQ/ehAAWFRW5JUcOBTljjzuSBw4cyEIuqBih9shMxchf+Vv+9Q8QxI9hZpOJG4mZkokdPHjQI7lVGRkVq1etqvBEkgZoJCSZ1YmTkpLCeE3ecczBXnpDAhtlMps5u7Pxk9yhQ4coB3RNDoRWpqdXYBnSgZwuY+VKtySpjffffz8LybO/JIWknOTkZDXvzLHP4UXp8FGA7HkMFYKqfSZJ5A4fPuyWHBFJZ+QUKpUWAbqWSDLCbkkWFxf7RZIwk3KeAAfWzCV+sH2S5XAqxHFqJJISVPBKUKFQcB999FGmR3LLl1fcJXIgRuEXCepp6bv0FSvoN7ckaeCoDx/IiQjz1ClT1AgWHGeMZXyC5Y6GX1qzJhmFg1BR5K3h9evXpyI7iHFHbvmyZRXNICKXy7UURvFDKvqOflvx4otuSaJtzYYNG1J90CARDMpYvTqRV/0Bgm2QKvowf/78RJvVKqUR8WamyPFC3ZFbtnSpnZzMiRyfpIyRfBED4YFkqLe5R1gJ8/PPP/8Yq0ZctM57Mv9kEX9wZmbmRNPwsIzcrqfGS0tLW5zPAAlo2pIlFc3NzbogmUxLGzoe8kkrlaGyS9PSKu42Nz9AktqmPryYpxgE5YQZa2Awq3rQ1cavhG2cRjU1NXXOnDHjSzHH9SENoT1Ol/EkBiF03bp1U//6+uvTqfHq6urmTbm5lXdbWvpJO5Rl+7LQA4NoaHAwZkxsbPAHH374x2nTpo3r7u7WFx04UA1n84NEKu1zd3iEpUGOEC306tWrK8bHx6vZDY04x+av887239ihv+Dve/acR7h1QyKR6EQi0bDLTNdikRqHhmJ5Z+8CIcqSVnwlxyeJtmLI1Phfo61WkVjsun+UhQZDtrz22uT8Xbvmsa+3Qf7hdeu+t7eXzuK+6MLDicV6AHeZWmP0FFhawtEOByCDGO1Of8nxScIqIjFwcrRB24G9sKIBl2WtVrHZYlHBctRVVVUrsAIoXG3duzo+W8TO4gWXL11qXLRo0TcwUx06ooP//4uzCfId9oE1m0PKy8uffWrOnATe7mC5t9Olckchqpifnz8ZQSwdesp8WToegYgIC2HauXPnZB65cmdyPh2A0qWCTRs3fvPZ5583IH+j+Wj8DTUpIscLkiEI9yYeKi5+li4teDoA9ekIG27YnJWZefbUqVM/i+6RHPoNSBI5GeZnyOLFi8d/fOTIc1KplBvpEbbjWQH5lJJvutTzl82bzx89erQRDqcfJAfZJYDRPsoWshsecjiW4JdffjnhQFHRPLo8xPpfBfkiINdIyFz3FhZ+V1BQcBMk9fB0AxDTKGpTBHwSiBLkVLt3707dlpf3B2aWVnaN5OOAXwS6dOlS05o1a6ratNo+O8l72jQHUJukNc5GWgM5TUxM6CeffDLr6aefjme/G9lx38lAXATiz0kKYMfRi06nGyosLPwBGq1DG4MCodAAskM8orYRkLpHzGaTYVFUoD05NJacl5f3u5CQEBnvYh4tB9dgpgJMnYBfxvuUfxrV2NjY897+/T8iE78D72YE0UEAM7LF1soTAY+0kLdMOYRMMQjE5PDWQZs3b57w2pYtTyQkJIQ7X8ZDdHX/Mh6WjFG5TrmQXaeMu39Q2dk5UFZW1oj8sKmysrKHETRRRMK0yifqIEXa4lgEJZk9e3Y40qN4eMkEut3ET1DYdcqvMf8eAEJ7MaNB0BHWbWXn+g9cXSay1d9/347gu/vmTz/136qpGUAKZezp6TGz0yYuLi4uaFJKijL18ceDEVxHTJs+PToyMlLp1AcNVCFdKoDXNrmJR73Gfw8rZFqZkEpb4J5K1qbEmwK84RMG+CKdhsWydKBKl9LDfKzXy/aFTrJwqy1gi+go/1lBKIvu3f1ZQT3LXvpGC8D/BBgAwjgWQAHlHQgAAAAASUVORK5CYII="
    }
}
