import android.content.Context
import android.media.MediaMetadataRetriever
import android.net.Uri
import android.util.Log
import java.io.File
import java.io.FileInputStream

internal object MetaDataUtil {

    fun getVideoDuration(videoFile: File): Long {
        val retriever = MediaMetadataRetriever()
        return try {
            val fileInputStream = FileInputStream(videoFile)
            try {
                retriever.setDataSource(fileInputStream.fd)
                val durationStr = retriever.extractMetadata(MediaMetadataRetriever.METADATA_KEY_DURATION)
                durationStr?.toLong() ?: 0L
            } finally {
                fileInputStream.close()
            }
        } catch (e: IllegalArgumentException) {
            e.printStackTrace()
            Log.e("VideoDuration", "Failed to retrieve video duration: ${e.message}")
            0L
        } catch (e: Exception) {
            e.printStackTrace()
            Log.e("VideoDuration", "Unexpected error: ${e.message}")
            0L
        } finally {
            retriever.release()
        }
    }
}