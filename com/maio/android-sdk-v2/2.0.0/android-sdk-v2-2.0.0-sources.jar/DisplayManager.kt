import android.content.MutableContextWrapper
import android.webkit.WebView
import jp.maio.sdk.android.v2.advideoview.VideoViewWrapper
import jp.maio.sdk.android.v2.player.PlayableView

class DisplayManger {
    companion object {
        private lateinit var instance: WebView
        private lateinit var instance1: MutableContextWrapper
        private lateinit var instance3: VideoViewWrapper
        private lateinit var instance4: PlayableView
        private lateinit var instance5: CloseButtonView
        fun getWebview(): WebView {
            return instance
        }
        fun setWebview(webview:WebView) {
            instance = webview
        }
        fun getContext(): MutableContextWrapper {
            return instance1
        }
        fun setContext(context:MutableContextWrapper) {
            instance1 = context
        }
        internal fun getVideoView(): VideoViewWrapper {
            return instance3
        }
        internal fun setVideoView(videoView:VideoViewWrapper) {
            instance3 = videoView
        }

        internal fun getPlayableView(): PlayableView {
            return instance4
        }
        internal fun setPlayableView(playableView: PlayableView) {
            instance4 = playableView
        }

        internal fun getCloseButtonView(): CloseButtonView {
            return instance5
        }
        internal fun setCloseButtonView(closeButtonView: CloseButtonView) {
            instance5 = closeButtonView
        }
    }
}