package jp.maio.sdk.android.v2

import CloseButtonView
import DisplayManger
import android.app.Activity
import android.content.res.Configuration
import android.os.Bundle
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.view.WindowManager
import android.webkit.WebView
import android.widget.FrameLayout
import jp.maio.sdk.android.v2.player.PlayableView

class PlayableActivity : Activity() {

    lateinit var closeButton: CloseButtonView
    private val _isClosed = false
    private lateinit var playableView: PlayableView
    lateinit var web: WebView
    var closeContent = false;
    private var isReturningFromStore = false

    override fun onBackPressed() {}
    override fun onPause() {
        super.onPause()
        triggerEventback(web, playableView.getEventBackId("1","onDisappear"))
    }

    override fun onResume() {
        super.onResume()
        if(isReturningFromStore) {
            triggerEventback(web, playableView.storeCloseEventbackId)
        }
        triggerEventback(web, playableView.getEventBackId("1","onAppear"))
    }

    override fun onConfigurationChanged(newConfig: Configuration) {
        super.onConfigurationChanged(newConfig!!)
        window.setFlags(
            WindowManager.LayoutParams.FLAG_FULLSCREEN,
            WindowManager.LayoutParams.FLAG_FULLSCREEN
        )
    }

    fun startAd(web: WebView) {
        var script = "window.miraibox.startAd()"
        web.evaluateJavascript(script, null);
    }

    fun triggerEventback(web: WebView, id: String) {
        val error = ""
        val result = "1"
        web.evaluateJavascript(
            "window.miraibox.eventback( $id, $result, $error)",
            null
        );
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        web = DisplayManger.getWebview()
        playableView  = DisplayManger.getPlayableView()
        closeButton = DisplayManger.getCloseButtonView()

        startAd(web)
        DisplayManger.getContext().baseContext = this


        val layout = FrameLayout(this)
        val layoutparams = FrameLayout.LayoutParams(
            ViewGroup.LayoutParams.MATCH_PARENT,
            ViewGroup.LayoutParams.MATCH_PARENT,
            Gravity.CENTER_HORIZONTAL or Gravity.CENTER_VERTICAL
        )
        layout.layoutParams = layoutparams


        closeButton.id = 4
        closeButton.bringToFront()
        closeButton.setOnClickListener({
            if(!closeContent) {
                triggerEventback(web, playableView.notifyPlayableClosedEventbackId)
                playableView.loadUrl("javascript:setTimeout(Maio.closeAd(true), 0);")
                closeContent = true
            }
            else {
                playableView.onPlayableClosed()
                this.finish();
            }
        })


      //  val animation = AlphaAnimation(0f, 1f)
      //  animation.duration = 1000
     //   closeButton.startAnimation(animation)
        closeButton.setVisibility(View.INVISIBLE)

        layout.addView(web)
        layout.addView(playableView)
        layout.addView(closeButton)

        setContentView(layout)

        playableView.bringToBackListener = {
            swapViews(layout, false)
            closeContent = true
        }
    }

    private fun swapViews(layout: FrameLayout, bringWebToFront: Boolean) {
        val web = layout.getChildAt(0)
        val playableView = layout.getChildAt(1)
        val closeButton = layout.getChildAt(2)

        // Remove web and playableView
        layout.removeViewAt(0)
        layout.removeViewAt(0) // index shifts after first removal

        if (bringWebToFront) {
            layout.addView(playableView, 0)
            layout.addView(web, 0)
        } else {
            layout.addView(web, 0)
            layout.addView(playableView, 0)
        }

        // Add closeButton again to make sure it's always on top
        layout.removeViewAt(2) // Remove the closeButton to add it back at the top
        layout.addView(closeButton)
    }
}
